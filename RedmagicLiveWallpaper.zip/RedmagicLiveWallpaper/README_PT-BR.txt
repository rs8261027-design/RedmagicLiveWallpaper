REDMAGIC MAX CHARGE — PAPEL DE PAREDE DINÂMICO

O que o projeto faz:
- Usa a arte REDMAGIC incluída como fundo.
- Lê a porcentagem real da bateria do Android.
- Atualiza o relógio automaticamente.
- A barra de energia acompanha a porcentagem real.
- Anima o brilho do painel e muda a cor durante o carregamento ou quando a bateria está baixa.
- Desenha somente enquanto o papel de parede está visível para reduzir consumo.

IMPORTANTE:
Este ZIP contém o PROJETO-FONTE Android, não um APK já instalado. Não foi possível compilar/assinar o APK neste ambiente. Para gerar o APK, abra a pasta RedmagicLiveWallpaper no Android Studio atualizado, aguarde a sincronização do Gradle e use Build > Build APK(s). Depois instale o APK no telefone e escolha “REDMAGIC MAX CHARGE” em Configurações > Papel de parede > Papéis de parede animados.

Requisitos de compilação: Android Studio recente, JDK 17, Android SDK 35 e internet para baixar dependências Gradle.

Observação: alguns launchers Samsung podem cortar um pouco as bordas dependendo da resolução; a imagem usa enquadramento central para se adaptar.
