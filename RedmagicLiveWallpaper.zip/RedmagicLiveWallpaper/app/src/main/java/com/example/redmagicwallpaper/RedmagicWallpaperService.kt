package com.example.redmagicwallpaper

import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.Color
import android.content.Intent
import android.content.IntentFilter
import android.content.BroadcastReceiver
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

class RedmagicWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = RedmagicEngine()

    inner class RedmagicEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visibleNow = false
        private var batteryPct = 97
        private var isCharging = false
        private var bitmap: Bitmap? = null
        private var startTime = System.currentTimeMillis()
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent == null) return
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (level >= 0 && scale > 0) batteryPct = (level * 100f / scale).toInt().coerceIn(0, 100)
                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
                drawFrame()
            }
        }

        private val frame = object : Runnable {
            override fun run() {
                if (!visibleNow) return
                drawFrame()
                handler.postDelayed(this, 50L)
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            try { bitmap = assets.open("redmagic_wallpaper.png").use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { bitmap = null }
            registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }

        override fun onDestroy() {
            visibleNow = false
            handler.removeCallbacks(frame)
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            bitmap?.recycle(); bitmap = null
            super.onDestroy()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            visibleNow = visible
            handler.removeCallbacks(frame)
            if (visible) handler.post(frame)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visibleNow = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        private fun drawFrame() {
            val holder: SurfaceHolder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) render(canvas)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
            }
        }

        private fun render(c: Canvas) {
            val w = c.width.toFloat(); val h = c.height.toFloat()
            c.drawColor(Color.BLACK)
            val bg = bitmap
            if (bg != null) {
                val scale = maxOf(w / bg.width, h / bg.height)
                val bw = bg.width * scale; val bh = bg.height * scale
                val dst = RectF((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f)
                paint.alpha = 255; paint.style = Paint.Style.FILL
                c.drawBitmap(bg, null, dst, paint)
            }

            // Cover the image's printed, static clock/battery panel with a live HUD.
            val pulse = (0.5 + 0.5 * kotlin.math.sin((System.currentTimeMillis() - startTime) / 420.0)).toFloat()
            val left = w * 0.17f; val right = w * 0.83f
            val top = h * 0.018f; val bottom = h * 0.158f
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(235, 5, 7, 22)
            c.drawRoundRect(RectF(left, top, right, bottom), w * 0.035f, w * 0.035f, paint)

            paint.style = Paint.Style.STROKE; paint.strokeWidth = maxOf(2f, w * 0.004f)
            paint.color = if (isCharging) Color.rgb(255, 40, 105) else Color.rgb(84, 73, 255)
            paint.alpha = (150 + pulse * 105).toInt()
            c.drawRoundRect(RectF(left, top, right, bottom), w * 0.035f, w * 0.035f, paint)
            paint.alpha = 255; paint.style = Paint.Style.FILL

            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            paint.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = w * 0.052f
            paint.color = Color.rgb(220, 229, 255)
            c.drawText(time, w * 0.5f, h * 0.052f, paint)

            val pctColor = if (batteryPct <= 15) Color.rgb(255, 55, 65) else if (isCharging) Color.rgb(255, 64, 130) else Color.rgb(177, 113, 255)
            paint.textSize = w * 0.105f
            paint.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            paint.color = pctColor
            paint.setShadowLayer(w * (0.012f + pulse * 0.008f), 0f, 0f, pctColor)
            c.drawText("$batteryPct%", w * 0.5f, h * 0.112f, paint)
            paint.clearShadowLayer()

            // Energy bar tracks the actual battery percentage.
            val barL = w * 0.29f; val barR = w * 0.71f; val barY = h * 0.125f
            paint.color = Color.rgb(44, 43, 75)
            c.drawRoundRect(RectF(barL, barY, barR, barY + h * 0.008f), 8f, 8f, paint)
            paint.color = pctColor
            c.drawRoundRect(RectF(barL, barY, barL + (barR - barL) * batteryPct / 100f, barY + h * 0.008f), 8f, 8f, paint)

            paint.textSize = w * 0.029f
            paint.typeface = Typeface.create("sans-serif", Typeface.BOLD_ITALIC)
            paint.color = Color.rgb(255, 187, 50)
            val status = if (isCharging) "MAX ⚡ CHARGING" else "MAX ⚡ CHARGE"
            c.drawText(status, w * 0.5f, h * 0.148f, paint)
        }
    }
}
